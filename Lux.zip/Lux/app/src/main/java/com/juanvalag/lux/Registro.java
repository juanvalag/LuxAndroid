package com.juanvalag.lux;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import negocio.Empresa;
import negocio.Persona;

public class Registro extends AppCompatActivity {

    private EditText nombre, apellidos, username, password, confirmacontra;
    private RadioButton rb_empresa, rb_persona;
    private Persona pers_temp;
    private Empresa empre_temp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        this.nombre= (EditText) findViewById(R.id.txt_nombres);
        this.apellidos=(EditText) findViewById(R.id.txt_apellidos);
        this.username=(EditText) findViewById(R.id.txt_usuario);
        this.password=(EditText) findViewById(R.id.txt_contrasena);
        this.confirmacontra=(EditText) findViewById(R.id.txt_confircontra);
        this.rb_persona=(RadioButton) findViewById(R.id.rb_persona);
        this.rb_empresa=(RadioButton) findViewById(R.id.rb_empresa);
    }

    public void onClick(View vi){
        if(vi.getId() == R.id.btn_iniciarsesion){
            String nombres, apelli, usuario, contraseña, conficontra;
            nombres= this.nombre.getText().toString();
            apelli= this.apellidos.getText().toString();
            usuario = this.username.getText().toString();
            contraseña = this.password.getText().toString();
            conficontra= this.confirmacontra.getText().toString();
            boolean valido=true;

            if(nombres.equals(""))
            {
                Toast.makeText(this, "Por favor ingrese los nombres", Toast.LENGTH_SHORT).show();
                valido = false;
            }else if(apelli.equals(""))
            {
                Toast.makeText(this, "Por favor ingrese los apellidos", Toast.LENGTH_SHORT).show();
                valido = false;
            }else if(usuario.equals(""))
            {
                Toast.makeText(this, "Por favor ingrese el nombre de usuario", Toast.LENGTH_SHORT).show();
                valido = false;
            }else if(contraseña.equals(""))
            {
                Toast.makeText(this, "Por favor ingrese la contraseña", Toast.LENGTH_SHORT).show();
                valido = false;
            }else if(conficontra.equals("")){
                Toast.makeText(this, "Por favor confirme la contraseña", Toast.LENGTH_SHORT).show();
                valido=false;
            }else if(!contraseña.equals(conficontra)){
                Toast.makeText(this, "Las contrseñas no coinciden, por favor verifique", Toast.LENGTH_SHORT).show();
                valido=false;
            }
            if(!this.rb_persona.isChecked() && !this.rb_empresa.isChecked()){
                Toast.makeText(this, "No se ha seleccionado el tipo de usuario", Toast.LENGTH_SHORT).show();
                valido=false;
            }

            if(valido)
            {


                String tipo="";
                AdminSQLiteOpenHelper admin =new AdminSQLiteOpenHelper(this, "lux_basededatos", null, 1);
                SQLiteDatabase base = admin.getWritableDatabase();
                ContentValues contenedor = new ContentValues();
                if(this.rb_persona.isChecked()){
                   this.pers_temp = new Persona(nombres,apelli,usuario, contraseña);
                   this.empre_temp=null;
                }else{
                    empre_temp=new Empresa(nombres, apelli, usuario, contraseña);
                    this.pers_temp=null;
                }
                contenedor.put("nombre", nombres);
                contenedor.put("apellidos", apelli);
                contenedor.put("username", usuario);
                contenedor.put("contrasena", contraseña);
                if(this.pers_temp != null) {
                    contenedor.put("tipo", this.pers_temp.getTipo());
                }else{
                    contenedor.put("tipo", this.empre_temp.getTipo());
                }
                base.insert("usuarios", null, contenedor);
                base.close();
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show();
                this.reinicio();
            }
        }
    }

    private void reinicio(){
        Intent pasador = new Intent(this, Principal.class);
        startActivity(pasador);
    }

}
