package com.juanvalag.lux;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;


public class EmpresaInicio extends AppCompatActivity {

    private EditText jsons;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empresa_inicio);
        this.jsons= (EditText) findViewById(R.id.txt_json);
        this.conectar();
    }

    private void conectar(){

        String mensajeError = "No hay una conexion estable a internet";
        // el connectivity manager permite saber si hay conexion a internet y/o si se esta conectado a una red
        ConnectivityManager adminConexion= (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo infodeRed= adminConexion.getActiveNetworkInfo();
        if(infodeRed != null && infodeRed.isConnected()){
            // si hay conexion entonces se llama a la clase TareaDescargaWeb para que haga el trabajo de HtmlApi en un hilo
            // aparte al principal
            new TareaDescargaWeb().execute("http://www.json-generator.com/api/json/get/ceXxtEKxDS?indent=2");
        }else{
            this.jsons.setText(mensajeError);
        }
    }


    private class TareaDescargaWeb extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            // cuando se llama el metodo execute, esta clase hace en segundo plano la tarea de HtmlApi
            return HtmlApi.obtenerContenidoHtml(urls[0]);
        }

        @Override
        protected void onPostExecute(String resultado){
            // luego en este metodo se retornatodo lo que se encontro en el link
           jsons.setText(resultado);
        }
    }
}
