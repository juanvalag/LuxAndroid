package com.juanvalag.lux;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class HtmlApi {
    // se crea la clase HtmlApi para que ésta por medio de una conexion con la pagina saloicitada recoja el JSON o el html
    // que haya en el link

    public static String obtenerContenidoHtml(String link)
    {
    URL objeto=null;
    HttpURLConnection conexion =null;
    String respuesta= null;
    String textofinal= null;


    try{
        // se crea el objeto URL para accder a el
        objeto= new URL(link);
        // con url connection se abre la conexion con el link
        URLConnection conexionConUrl = objeto.openConnection();
        // el lector permite leer los datos de la url
        BufferedReader lectorDeIngreso= new BufferedReader(new InputStreamReader(conexionConUrl.getInputStream()));
        // se sacan todas la lineas del archivo que está en la url
        while((respuesta = lectorDeIngreso.readLine())!= null){
            textofinal+=respuesta+" \r\n";
        }
        lectorDeIngreso.close();
    }catch(MalformedURLException e)
    {
        e.printStackTrace();
    }catch (IOException ioe)
    {
        ioe.printStackTrace();
    }

    // se devuelve el string que contiene todas las lineas
    return textofinal;
    }
}
