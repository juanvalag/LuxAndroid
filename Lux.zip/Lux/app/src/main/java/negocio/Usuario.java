package negocio;

public class Usuario {

    // atributos
    private String nombre, apellidos, username, contraseña, tipo;

    //constructores
    public Usuario()
    {
        this.nombre = "";
        this.apellidos="";
        this.username="";
        this.contraseña="";
        this.tipo="";
    }

    public Usuario(String nombre, String apellidos, String username, String contraseña, String tipo)
    {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.username=username;
        this.contraseña=contraseña;
        this.tipo=tipo;
    }

    //metodos analizadores y modificadores

    public String getNombre()
    {
        return this.nombre;
    }
    public String getApellidos()
    {
        return this.apellidos;
    }

    public String getUsername()
    {
        return this.username;
    }

    public String getContraseña()
    {
        return this.contraseña;
    }

    public String getTipo()
    {
        return this.tipo;
    }

    //modificadores
    public void setNombre(String nombre)
    {
        this.nombre=nombre;
    }

    public void setApellidos(String apelli)
    {
        this.apellidos=apelli;
    }

    public void setUsername(String user){
        this.username=user;
    }
    public void setContraseña(String contra){
        this.contraseña= contra;
    }

    public void setTipo(String tipo)
    {
        this.tipo=tipo;
    }
    // visualizador




}
