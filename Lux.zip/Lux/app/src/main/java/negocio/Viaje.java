package negocio;

public class Viaje
{
    //atributos
    private String nombre;
    private double precio;
    private int dias;
    private Ruta ruta;
    private String destino;

    //constructores
    public Viaje(){
        this.precio=0.0;
        this.dias=0;
        this.ruta= new Ruta();
        this.destino="";
        this.nombre="";
    }

    public Viaje(String nombre, double precio, int dias, Ruta ruta, String destino)
    {
        this.precio=precio;
        this.dias=dias;
        this.ruta=ruta;
        this.destino=destino;
        this.nombre=nombre;
    }

    // analizadores
    public double getPrecio()
    {
        return this.precio;
    }

    public int getDias()
    {
        return this.dias;
    }

    public Ruta getRuta()
    {
        return this.ruta;
    }

    public String getDestino(){
        return this.destino;
    }

    public String getNombre()
    {
      return this.nombre;
    }

    //modificadores

    public void setPrecio(double precio){
        this.precio=precio;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }

    public void setRuta(Ruta ruta) {
        this.ruta = ruta;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setNombre(String nombre)
    {
        this.nombre=nombre;
    }

    //visualizadores
    @Override
    public String toString(){
        return this.nombre+","+this.precio+","+this.ruta.getNombre()+","+this.destino+","+this.dias;
    }
}
