package negocio;

public class Ruta {

    // atributos
    private String nombre, ciudades, hoteles, actividades, transporte;

    public Ruta()
    {
        this.nombre="";
        this.ciudades="";
        this.hoteles="";
        this.actividades="";
        this.transporte="";
    }

    public Ruta(String name,String ciudades, String hoteles, String acti, String trans)
    {
       this.nombre=name;
       this.ciudades=ciudades;
       this.hoteles=hoteles;
       this.actividades=acti;
       this.transporte=trans;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudades() {
        return ciudades;
    }

    public void setCiudades(String ciudades) {
        this.ciudades = ciudades;
    }

    public String getHoteles() {
        return hoteles;
    }

    public void setHoteles(String hoteles) {
        this.hoteles = hoteles;
    }

    public String getActividades() {
        return actividades;
    }

    public void setActividades(String actividades) {
        this.actividades = actividades;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }

    @Override
    public String toString(){
        return this.nombre+","+this.ciudades+","+this.actividades+","+this.hoteles+","+this.transporte;
    }
}
