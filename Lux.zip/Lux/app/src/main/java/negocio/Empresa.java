package negocio;

public class Empresa extends Usuario {


    public Empresa()
    {
        super();
    }

    public Empresa(String nombre, String apellidos, String username, String contraseña)
    {
        super(nombre, apellidos, username, contraseña, "Empresa");
    }
}
