package negocio;

public class Persona extends Usuario {

    public Persona(){
        super();
    }

    public Persona(String nombre, String apellidos, String username, String contraseña)
    {
        super(nombre, apellidos, username, contraseña, "Persona");
    }

    @Override
    public String toString(){
        return this.getNombre()+","+this.getApellidos()+","+this.getUsername()+","+this.getContraseña();
    }
}
